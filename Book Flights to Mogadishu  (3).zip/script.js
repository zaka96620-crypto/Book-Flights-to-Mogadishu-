// Get the search button
const searchBtn = document.getElementById("searchBtn");

// Listen for button click
searchBtn.addEventListener("click", function () {

    // Get form values
    const from = document.querySelector(
        '.input-group input[placeholder="Mogadishu (MGQ)"]'
    ).value;

    const to = document.querySelectorAll(
        '.input-group input[placeholder="Destination"]'
    )[0].value;

    const dates = document.querySelectorAll(
        '.input-group input[type="date"]'
    );

    const departure = dates[0].value;
    const returnDate = dates[1].value;

    const passengers = document.querySelector(
        ".input-group select"
    ).value;


    // Check required information
    if (from === "" || to === "" || departure === "") {

        alert("Please enter your departure, destination and date.");

        return;
    }


    // Display search information
    alert(
        "Flight Search\n\n" +
        "From: " + from + "\n" +
        "To: " + to + "\n" +
        "Departure: " + departure + "\n" +
        "Return: " + returnDate + "\n" +
        "Passengers: " + passengers
    );

});